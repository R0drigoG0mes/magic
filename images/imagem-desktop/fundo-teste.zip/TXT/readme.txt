Bear Hugs
http://www.dafont.com/bear-hugs.font